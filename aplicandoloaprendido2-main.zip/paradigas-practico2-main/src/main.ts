import { menu } from "./menu";

function main(): void {
    menu();
}

main();